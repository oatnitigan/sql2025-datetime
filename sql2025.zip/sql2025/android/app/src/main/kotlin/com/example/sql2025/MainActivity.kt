package com.example.sql2025

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
